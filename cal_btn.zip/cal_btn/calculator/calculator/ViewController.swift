//
//  ViewController.swift
//  calculator
//
//  Created by Cha White on 3/22/21.
//  Copyright © 2021 Cha White. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func equalbtn(_ sender: Any) {
       }
    
    @IBAction func clearbtn(_ sender: Any) {
    }
    
    @IBAction func dotbtn(_ sender: Any) {
    }
    
    @IBAction func signbtn(_ sender: Any) {
    }
    
    @IBAction func plusbtn(_ sender: Any) {
    }
    
    @IBAction func subbtn(_ sender: Any) {
    }
    
    @IBAction func multibtn(_ sender: Any) {
    }
    
    @IBAction func divisionbtn(_ sender: Any) {
    }
    //Display an alert message. displayAlert(msgTitle: "Ready", msgContent: "Go")
    func displayAlert(msgTitle:String, msgContent:String){let alertController = UIAlertController(title: msgTitle, message: msgContent,preferredStyle: .alert);let defaultAction = UIAlertAction(title: "Close", style: .default, handler: nil);alertController.addAction(defaultAction);present(alertController, animated: true, completion: nil)
        
    }
     //Action function for the "Click ME" button
        @IBAction func clearbtn(_ sender: Any) {
            displayAlert(msgTitle: "Backspace" , msgContent: "Yes, correct button")
    
            
        }
        
    }


