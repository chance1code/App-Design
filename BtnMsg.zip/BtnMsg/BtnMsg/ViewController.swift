//
//  ViewController.swift
//  BtnMsg
//
//  Created by Cha White on 3/22/21.
//  Copyright © 2021 Cha White. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btn: UIButton!
    
    var count: Int = 0 //variable
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    //Display an alert message. displayAlert(msgTitle: "Ready", msgContent: "Go")
func displayAlert(msgTitle:String, msgContent:String)
{let alertController = UIAlertController(title: msgTitle, message: msgContent,preferredStyle: .alert)
    let defaultAction = UIAlertAction(title: "Close", style: .default, handler: nil);alertController.addAction(defaultAction);present(alertController, animated: true, completion: nil)
    
    }
     
    //Action function for the "Click ME" button
    @IBAction func btnAction(_ sender: Any) {
        displayAlert(msgTitle: "Title of MSG" , msgContent: "Yes, correct button")
        count = count + 1
        if count % 2 == 0 {
            btn.setTitle("ME: \(count)", for: .normal)
        } else {
            btn.setTitle("YOU: \(count)", for: .normal)
        }
        
    }
    
}

