//
//  ViewController.swift
//  EditBtn
//
//  Created by Cha White on 3/22/21.
//  Copyright © 2021 Cha White. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
 
@IBOutlet weak var Taskbtn: NSLayoutConstraint!
    
@IBOutlet weak var datebtn: UITextField!
@IBOutlet weak var tbtn: UITextField!
    
  // array to hold all task numbers
    var Num : [Int] = []
    // array to hold all task descriptions
    var Desc : [String] = []
    var currTask : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
    func displayAlert(msgTitle:String, msgContent:String) {
    let alertController = UIAlertController(title: msgTitle, message: msgContent, preferredStyle: .alert)
    let defaultAction = UIAlertAction(title: "Close", style: .default, handler: nil)
    alertController.addAction(defaultAction)
    present(alertController, animated: true, completion: nil)
        
    }
   
    @IBAction func sub(_ sender: Any) {
        
        
    }
    
}

