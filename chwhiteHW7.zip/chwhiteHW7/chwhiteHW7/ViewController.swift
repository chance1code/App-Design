//
//  ViewController.swift
//  chwhiteHW7
//
//  Created by Cha White on 5/10/21.
//  Copyright © 2021 Cha White. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var myDistanceLabel: UILabel!
    @IBOutlet weak var myTimeLabel: UILabel!
    @IBOutlet weak var myBtnOutlet: UIButton!
    @IBOutlet weak var myMapView: MKMapView!
    var myDistance:Double = 0.0 //holds the distanc the user covers
      let locationManager:CLLocationManager! = CLLocationManager() //for reading GPS updates
      var previousLat: Double = 0.0
      var previousLong:Double = 0.0 //holds the previous GPS update
      var isFirstPos:Bool = true
      var myMarkers: [MKAnnotation] = []  //holds all the annotations outlining the path
      var myTime:Double = 0
      
    override func viewDidLoad() {
           super.viewDidLoad()
           // Do any additional setup after loading the view.
           myDistanceLabel.text = "0.00 miles"
                  myDistance = 0.0
                  myBtnOutlet.setTitle("START", for: .normal)
                  isFirstPos = true
                  myTimeLabel.text = "0:00:00"
                  
                  
                  myMapView.delegate = self
                  myMapView.mapType = .standard
                  myMapView.isZoomEnabled = true
                  myMapView.isScrollEnabled = true
                  
                  
                  
                  //ask 4 reading GPS data (permission)
                  locationManager.requestWhenInUseAuthorization()
                  if CLLocationManager.locationServicesEnabled() {
                      locationManager.delegate = self
                      locationManager.desiredAccuracy = kCLLocationAccuracyBest
                      locationManager.stopUpdatingLocation()
                  } else {
                      //message telling the user GPS updates are allowed....
                  }
                  
                  let tmpRegion = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 30.092540, longitude: -95.990437), latitudinalMeters: 515, longitudinalMeters: 520)
                  myMapView.setRegion(tmpRegion, animated: true)
                  
                  NotificationCenter.default.addObserver(self, selector: #selector(didBecomeActive), name: UIApplication.didBecomeActiveNotification, object: nil)
                  NotificationCenter.default.addObserver(self, selector: #selector(appMovedToBackground), name: UIApplication.willResignActiveNotification, object: nil)
                  
              }
              
              //Called automatically when your app becomes active
              @objc func didBecomeActive() {
                     myDistance = 0.0
                     myBtnOutlet.setTitle("START", for: .normal)
                     myDistanceLabel.text = "0.00 miles"
                     myTimeLabel.text = "0:00:00"
                     //Set the exercise time to be 0:00:00
                 }
                 
              //called when your app goes to background (inactive)
              @objc func appMovedToBackground() {
                     locationManager.stopUpdatingLocation() //stop GPS Update
                     for annotation in myMarkers {//remove all the markers from map
                         myMapView.removeAnnotation(annotation)
                     }
                     myMarkers.removeAll()  //clear the array of the annotations
              }

              //button function
              @IBAction func StartStopAction(_ sender: Any) {
                  if myBtnOutlet.titleLabel?.text == "START" {//Now we need to start tracking
                      isFirstPos = true
                      myBtnOutlet.setTitle("STOP", for: .normal)
                      myDistanceLabel.text = "0.00 Miles"
                      myDistance = 0.0
                      locationManager.startUpdatingLocation() //Start updating GPS
                      myTimeLabel.text = "0:00:00"
                      myTime = 0.0
                      
                      for annotation in myMarkers {
                          myMapView.removeAnnotation(annotation)
                      }
                      myMarkers.removeAll()
                      //start timer
                  } else {//Now we need to stop tracking
                      myBtnOutlet.setTitle("START", for: .normal)
                      locationManager.stopUpdatingLocation() //Start updating GPS
                      //Stop the timer
                  }
              }
              
              //called by the system when GPS data changes
              func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
                  let locValue:CLLocationCoordinate2D = manager.location!.coordinate//the GPS new location
                  let myLocation = CLLocationCoordinate2D(latitude: locValue.latitude, longitude: locValue.longitude) //extract Lat. Long. (latest location update)
                  
                  if isFirstPos {//first GPS update
                      isFirstPos = false
                      previousLat = Double(myLocation.latitude)
                      previousLong = Double(myLocation.latitude)
                      return
                  }
                  
                  //add the delta-distance to the myDistance
                  let deltaD = calDist(lat1: previousLat, lon1: previousLong,
                                       lat2: Double(myLocation.latitude), lon2: Double(myLocation.latitude))
                  
                  //if deltaD < 0.3 {
                      myDistance = myDistance + deltaD
                      myMapView.setCenter(myLocation, animated: true)//the now location becomes the new center of the map
                      let myAnnotation = MKPointAnnotation()
                      myAnnotation.coordinate = myLocation
                      myMapView.addAnnotation(myAnnotation)
                      myMarkers.append(myAnnotation)
                  //}
                  
                  previousLat = Double(myLocation.latitude)
                  previousLong = Double(myLocation.latitude)
              
                  let tmpStr = String(format: "%.2f", myDistance)
                  myDistanceLabel.text = tmpStr + " miles"
              }
              
              
              //Calculate distance between two locations (unit: mile)
              func calDist(lat1:Double, lon1:Double, lat2:Double, lon2:Double) -> Double {
                  var theta:Double
                  var dist:Double
                  theta = lon1 - lon2
                  dist = sin(lat1*3.14/180) * sin(lat2*3.14/180) + cos(lat1*3.14/180) * cos(lat2*3.14/180) * cos(theta*3.14/180);
                  
                  dist = acos(dist);
                  dist = dist * 180 / 3.1415926535;
                  dist = dist * 60 * 1.1515;
                  return dist
              }
       }


